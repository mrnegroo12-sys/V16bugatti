package com.sketchbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import android.graphics.Bitmap
import android.view.Display
import android.os.Build
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class DrawService : AccessibilityService() {

    companion object { var instance: DrawService? = null }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var calib: View? = null
    private var card: View? = null
    private var banner: View? = null
    private var rect: RectF? = null
    private var layerP0: PointF? = null
    private var layerP1: PointF? = null
    // [أيقونة اللون، حقل HEX، زر تأكيد (اختياري)، إغلاق المحرر]
    private var colorPts: List<PointF?>? = null
    private var fillSel: List<PointF?>? = null
    private var brushSel: List<PointF?>? = null
    private var smudgeSel: List<PointF?>? = null
    private var curColor = -1
    private var stepNo = 0

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadPrefs()
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun removeOverlay(v: View?) {
        if (v == null) return
        try { wm?.removeView(v) } catch (_: Exception) {}
    }

    private fun cleanup() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(panel)
        removeOverlay(calib)
        removeOverlay(card)
        removeOverlay(banner)
        panel = null
        calib = null
        card = null
        banner = null
        instance = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    // ---------- الحفظ ----------
    private fun prefs() = getSharedPreferences("sb", Context.MODE_PRIVATE)

    private fun loadPrefs() {
        val p = prefs()
        if (p.contains("l")) {
            rect = RectF(p.getFloat("l", 0f), p.getFloat("t", 0f), p.getFloat("r", 0f), p.getFloat("b", 0f))
        }
        if (p.contains("lx0")) {
            layerP0 = PointF(p.getFloat("lx0", 0f), p.getFloat("ly0", 0f))
            layerP1 = PointF(p.getFloat("lx1", 0f), p.getFloat("ly1", 0f))
        }
        fillSel = decodePts(p.getString("fillSel", null))
        brushSel = decodePts(p.getString("brushSel", null))
        smudgeSel = decodePts(p.getString("smudgeSel", null))
        colorPts = decodePts(p.getString("colorSel", null))?.takeIf { it.size == 4 }
    }

    private fun encodePts(l: List<PointF?>) =
        l.joinToString(";") { if (it == null) "n" else "${it.x},${it.y}" }

    private fun decodePts(s: String?): List<PointF?>? {
        if (s.isNullOrEmpty()) return null
        return try {
            s.split(";").map {
                if (it == "n") null else { val a = it.split(","); PointF(a[0].toFloat(), a[1].toFloat()) }
            }
        } catch (_: Exception) { null }
    }

    private fun saveRect(r: RectF) {
        prefs().edit()
            .putFloat("l", r.left).putFloat("t", r.top).putFloat("r", r.right).putFloat("b", r.bottom).apply()
    }

    private fun saveLayers(a: PointF, b: PointF) {
        prefs().edit()
            .putFloat("lx0", a.x).putFloat("ly0", a.y).putFloat("lx1", b.x).putFloat("ly1", b.y).apply()
    }

    private fun saveColorPts(l: List<PointF?>) {
        prefs().edit().putString("colorSel", encodePts(l)).apply()
    }

    private fun clearColorPts() {
        prefs().edit().remove("colorSel").apply()
        colorPts = null
    }

    // ---------- الشريط العائم ----------
    private fun showPanel() {
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun tv(t: String) = TextView(this@DrawService).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
        }
        val handle = tv("☰")
        val bStart = tv("▶ ابدأ")
        val bStop = tv("■ إيقاف")
        val bCal = tv("⛶ المنطقة")
        val bLay = tv("⧉ طبقات")
        val bColor = tv("🎨 اللون")
        val bFill = tv("🪣 أداة Fill")
        val bBrush = tv("✏ الفرشاة")
        val bTest = tv("🧪 اختبار اللون")
        val bMeasure = tv("📏 قياس الفرشاة")
        val bSmudge = tv("👆 أداة التنعيم")
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(handle); addView(bStart); addView(bStop)
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bCal); addView(bLay); addView(bColor)
        }
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bFill); addView(bBrush); addView(bTest)
        }
        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bMeasure)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD222222.toInt())
            addView(row1); addView(row2); addView(row3); addView(row4)
        }
        val lp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (240 * d).toInt()
        }

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    try { w.updateViewLayout(root, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        bStart.setOnClickListener { startDrawing() }
        bStop.setOnClickListener { stop(); toast("تم الإيقاف") }
        bCal.setOnClickListener { calibrate() }
        bLay.setOnClickListener { teachLayers() }
        bColor.setOnClickListener { teachColor() }
        bColor.setOnLongClickListener {
            clearColorPts()
            toast("تم مسح تعليم اللون: سيعود الاختيار اليدوي")
            true
        }

        bTest.setOnClickListener { testColor() }
        bFill.setOnClickListener { teachTool(1) }
        bBrush.setOnClickListener { teachTool(0) }
        bMeasure.setOnClickListener { measureBrush() }
        bFill.setOnLongClickListener {
            fillSel = null; prefs().edit().remove("fillSel").apply()
            toast("تم مسح تعليم أداة Fill: سيطلب منك اختيارها يدوياً")
            true
        }
        bBrush.setOnLongClickListener {
            brushSel = null; prefs().edit().remove("brushSel").apply()
            toast("تم مسح تعليم الفرشاة: سيطلب منك اختيارها يدوياً")
            true
        }

        w.addView(root, lp)
        panel = root
    }

    // ---------- بطاقة اختيار اللون (الوضع اليدوي) ----------
    private fun showColorCard(ph: Phase, idx: Int, total: Int, onContinue: () -> Unit) {
        val w = wm ?: return
        removeOverlay(card)
        val d = resources.displayMetrics.density
        val hex = String.format("#%06X", 0xFFFFFF and ph.color)
        setClipboard(hex)

        val swatch = View(this).apply { setBackgroundColor(ph.color) }
        val title = TextView(this).apply {
            text = "المرحلة $idx/$total: ${ph.label}\n$hex"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding((10 * d).toInt(), 0, 0, 0)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(swatch, LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()))
            addView(title)
        }
        val btn = TextView(this).apply {
            text = "▶ متابعة بعد اختيار اللون"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF2E7D32.toInt())
            setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE222222.toInt())
            setPadding((12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt())
            addView(top)
            addView(btn)
        }
        val lp = overlayParams(
            (320 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (40 * d).toInt()
        }
        btn.setOnClickListener {
            removeOverlay(root)
            card = null
            onContinue()
        }
        w.addView(root, lp)
        card = root
    }

    // ---------- شاشات التعليم ----------
    private class CalibView(ctx: Context) : View(ctx) {
        var a: PointF? = null
        var b: PointF? = null
        private val p = Paint().apply {
            color = 0xFFFF4081.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x33000000)
            val pa = a
            val pb = b
            if (pa != null) c.drawCircle(pa.x, pa.y, 20f, p)
            if (pb != null) c.drawCircle(pb.x, pb.y, 20f, p)
            if (pa != null && pb != null) c.drawRect(
                Math.min(pa.x, pb.x), Math.min(pa.y, pb.y),
                Math.max(pa.x, pb.x), Math.max(pa.y, pb.y), p
            )
        }
    }

    private class TapView(ctx: Context) : View(ctx) {
        val pts = ArrayList<PointF>()
        private val p = Paint().apply {
            color = 0xFF40C4FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x22000000)
            for (pt in pts) c.drawCircle(pt.x, pt.y, 24f, p)
        }
    }

    private fun fullScreenParams() = overlayParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    )

    // زاويتا الصورة المرجعية داخل Sketchbook
    private fun calibrate() {
        val w = wm ?: return
        if (calib != null) return
        val v = CalibView(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (v.a == null) {
                    v.a = PointF(e.rawX, e.rawY)
                    v.invalidate()
                    toast("الآن اضغط الزاوية السفلية اليمنى لمنطقة الرسم")
                } else if (v.b == null) {
                    val a = v.a!!
                    v.b = PointF(e.rawX, e.rawY)
                    val r = RectF(
                        Math.min(a.x, e.rawX), Math.min(a.y, e.rawY),
                        Math.max(a.x, e.rawX), Math.max(a.y, e.rawY)
                    )
                    v.invalidate()
                    if (r.width() < 150f || r.height() < 150f) {
                        toast("المساحة صغيرة جداً، أعد المحاولة")
                    } else {
                        rect = r
                        saveRect(r)
                        toast("تم حفظ منطقة الرسم")
                    }
                    handler.postDelayed({
                        removeOverlay(v)
                        calib = null
                    }, 1200)
                }
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        toast("اضغط الزاوية العليا اليسرى لمنطقة الرسم")
    }

    // ---------- التعليم خطوة بخطوة ----------
    private class Step(val text: String, val wait: Boolean)

    private fun showBanner(text: String) {
        val w = wm ?: return
        removeOverlay(banner)
        val d = resources.displayMetrics.density
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 16f
        tv.gravity = Gravity.CENTER
        tv.setBackgroundColor(0xEE1565C0.toInt())
        tv.setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
        val lp = overlayParams(
            (340 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (60 * d).toInt()
        w.addView(tv, lp)
        banner = tv
    }

    // خطوة ضغط: تضغط أنت المكان فيحفظه التطبيق (لا يصل الضغط إلى Sketchbook)
    private fun tapStep(text: String, onSkip: (() -> Unit)? = null, onTap: (PointF) -> Unit) {
        val w = wm ?: return
        val v = TapView(this)
        var done = false
        showBanner(text)
        var skipView: View? = null
        fun cleanupStep() {
            removeOverlay(v)
            calib = null
            removeOverlay(banner)
            banner = null
            removeOverlay(skipView)
            skipView = null
        }
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP && !done) {
                done = true
                val p = PointF(e.rawX, e.rawY)
                v.pts.add(p)
                v.invalidate()
                handler.postDelayed({
                    cleanupStep()
                    onTap(p)
                }, 350)
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        if (onSkip != null) {
            val d = resources.displayMetrics.density
            val sk = TextView(this)
            sk.text = "⏭ تخطي (غير مطلوب)"
            sk.setTextColor(Color.WHITE)
            sk.textSize = 16f
            sk.gravity = Gravity.CENTER
            sk.setBackgroundColor(0xFF6A1B9A.toInt())
            sk.setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            val lp = overlayParams(
                (300 * d).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = (40 * d).toInt()
            sk.setOnClickListener {
                if (!done) {
                    done = true
                    cleanupStep()
                    onSkip()
                }
            }
            w.addView(sk, lp)
            skipView = sk
        }
    }

    // خطوة انتظار: تفعل أنت شيئاً في Sketchbook ثم تضغط متابعة
    private fun waitStep(text: String, onContinue: () -> Unit) {
        val w = wm ?: return
        removeOverlay(card)
        val d = resources.displayMetrics.density
        val msg = TextView(this)
        msg.text = text
        msg.setTextColor(Color.WHITE)
        msg.textSize = 15f
        val btn = TextView(this)
        btn.text = "▶ متابعة"
        btn.setTextColor(Color.WHITE)
        btn.textSize = 17f
        btn.gravity = Gravity.CENTER
        btn.setBackgroundColor(0xFF2E7D32.toInt())
        btn.setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xEE222222.toInt())
        root.setPadding((12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt())
        root.addView(msg)
        root.addView(btn)
        val lp = overlayParams(
            (320 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = (24 * d).toInt()
        btn.setOnClickListener {
            removeOverlay(root)
            card = null
            onContinue()
        }
        w.addView(root, lp)
        card = root
    }

    private fun teachSteps(steps: List<Step>, onDone: (List<PointF>) -> Unit) {
        if (calib != null) return
        val pts = ArrayList<PointF>()
        fun next(i: Int) {
            if (i >= steps.size) { onDone(pts); return }
            val st = steps[i]
            if (st.wait) waitStep(st.text) { next(i + 1) }
            else tapStep(st.text) { p -> pts.add(p); next(i + 1) }
        }
        next(0)
    }

    private fun teachLayers() {
        teachSteps(
            listOf(
                Step("افتح لوحة الطبقات في Sketchbook بنفسك، ثم اضغط متابعة", true),
                Step("اضغط أيقونة الطبقات", false),
                Step("اضغط زر ⊕ إضافة طبقة جديدة", false)
            )
        ) { l ->
            layerP0 = l[0]
            layerP1 = l[1]
            saveLayers(l[0], l[1])
            toast("تم حفظ الطبقات. أغلق لوحة الطبقات الآن")
        }
    }

    // تعليم اختيار أداة (Fill أو الفرشاة): أيقونة اللوحة ← الأداة ← زر الإغلاق (اختياري)
    private fun teachTool(kind: Int) {
        if (calib != null) return
        val name = when (kind) {
            1 -> "أداة التعبئة (Fill / سطل الطلاء)"
            2 -> "أداة التنعيم (Smudge)"
            else -> "الفرشاة أو القلم الرفيع"
        }
        val key = when (kind) { 1 -> "fillSel"; 2 -> "smudgeSel"; else -> "brushSel" }
        val pts = arrayOfNulls<PointF>(3)
        fun finish() {
            val l = pts.toList()
            when (kind) { 1 -> fillSel = l; 2 -> smudgeSel = l; else -> brushSel = l }
            prefs().edit().putString(key, encodePts(l)).apply()
            toast("تم حفظ $name. تأكد أن اللوحة مغلقة الآن")
        }
        tapStep("اضغط أيقونة الفرش في الشريط العلوي (التي تفتح لوحة الأدوات)") { a ->
            pts[0] = a
            waitStep("افتح لوحة الفرش بنفسك الآن ثم اضغط متابعة") {
                tapStep("اضغط على $name داخل اللوحة") { b ->
                    pts[1] = b
                    waitStep("اختر $name بنفسك الآن (اضغط عليها فعلاً) ثم اضغط متابعة") {
                        tapStep(
                            "اضغط الزر الذي يُغلق اللوحة (مثلاً أيقونة الفرش مجدداً)، وإن كانت تُغلق تلقائياً فاضغط تخطي",
                            onSkip = { finish() }
                        ) { c ->
                            pts[2] = c
                            finish()
                        }
                    }
                }
            }
        }
    }

    // تعليم اللون: ثلاث ضغطات فقط (الكتابة ومسح القيمة القديمة يتولاهما البوت وحده)
    private fun teachColor() {
        if (calib != null) return
        val pts = arrayOfNulls<PointF>(4)
        tapStep("المحرر مغلق الآن. اضغط أيقونة اللون في الشريط العلوي (عجلة الألوان)") { a ->
            pts[0] = a
            waitStep("افتح محرر اللون بنفسك، ثم اضغط متابعة") {
                tapStep("اضغط على حقل HEX (المكان الذي يُكتب فيه رمز اللون)") { b ->
                    pts[1] = b
                    tapStep("اضغط ✕ الذي يغلق محرر اللون") { d ->
                        pts[3] = d
                        val l = pts.toList()
                        colorPts = l
                        saveColorPts(l)
                        toast("تم حفظ اللون. أغلق محرر اللون الآن")
                    }
                }
            }
        }
    }

    // ---------- اللمسات ----------
    private fun tapAt(x: Float, y: Float, duration: Long, onDone: () -> Unit) = tapAtD(x, y, duration, 700L, onDone)

    private fun tapAtD(x: Float, y: Float, duration: Long, delay: Long, onDone: () -> Unit) {
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({ if (running) onDone() }, delay)
            }
            override fun onCancelled(d: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }

    private fun setClipboard(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("color", text))
        } catch (_: Exception) {}
    }

    // يضع رمز اللون في الحافظة ثم: فتح المحرر ← الضغط على HEX ← لصق ← إغلاق
    // ---------- قياس سمك الفرشاة الفعلي على الشاشة ----------
    private fun measureBrush() {
        val r = rect
        if (r == null) { toast("حدّد منطقة الرسم (⛶) أولاً"); return }
        if (Build.VERSION.SDK_INT < 30) { toast("القياس التلقائي يتطلب Android 11 فما فوق"); return }
        if (running) return
        running = true
        val cx = r.centerX()
        val cy = r.centerY()
        toast("سيرسم خطاً تجريبياً في وسط منطقة الرسم")
        val path = Path()
        path.moveTo(cx - 90f, cy)
        path.lineTo(cx + 90f, cy)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 500))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({ takeShotAndMeasure(cx, cy) }, 900)
            }
            override fun onCancelled(d: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }

    private fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) + Math.abs(Color.blue(a) - Color.blue(b))

    @android.annotation.TargetApi(30)
    private fun takeShotAndMeasure(cx: Float, cy: Float) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(res: ScreenshotResult) {
                    var t = 0f
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (bmp != null) {
                            val x = cx.toInt().coerceIn(0, bmp.width - 1)
                            val y0 = cy.toInt().coerceIn(0, bmp.height - 1)
                            val bg = bmp.getPixel(x, (y0 - 90).coerceIn(0, bmp.height - 1))
                            val centerDist = colorDist(bmp.getPixel(x, y0), bg)
                            if (centerDist > 60) {
                                val th = centerDist / 2
                                var up = 0
                                var yy = y0 - 1
                                while (yy >= 0 && up < 200 && colorDist(bmp.getPixel(x, yy), bg) > th) { up++; yy-- }
                                var dn = 0
                                yy = y0 + 1
                                while (yy < bmp.height && dn < 200 && colorDist(bmp.getPixel(x, yy), bg) > th) { dn++; yy++ }
                                t = (up + dn + 1).toFloat()
                            }
                        }
                    } catch (_: Exception) {}
                    running = false
                    if (t >= 1f) {
                        prefs().edit().putFloat("brushScreen", t).apply()
                        toast("سمك الفرشاة المقاس = ${t.toInt()} بكسل. تراجع ↩ عن الخط التجريبي، ثم أعد فتح صفحة التطبيق")
                    } else {
                        toast("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس")
                    }
                }
                override fun onFailure(errorCode: Int) {
                    running = false
                    toast("تعذّر أخذ لقطة الشاشة (رمز $errorCode)")
                }
            })
        } catch (e: Exception) {
            running = false
            toast("تعذّر القياس: ${e.message}")
        }
    }

    // كتابة رمز HEX مباشرة في الحقل المحدد عبر خدمة إمكانية الوصول (دون لصق)
    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable || (n.className?.toString()?.contains("EditText") == true)) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun typeHex(hex: String): Boolean {
        try {
            val root = rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
            val old = node.text?.toString() ?: ""
            val txt = if (old.startsWith("#")) hex else hex.removePrefix("#")
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            // تحديد القيمة القديمة كاملة ثم استبدالها
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, old.length)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt)
            var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (!ok) {
                node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                })
                ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            }
            if (ok && Build.VERSION.SDK_INT >= 30) {
                node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
            return ok
        } catch (_: Exception) {
            return false
        }
    }

    private fun applyColor(color: Int, onDone: () -> Unit) {
        val p = colorPts
        if (p == null || p.size < 4 || p[0] == null || p[1] == null) { onDone(); return }
        val hex = String.format("#%06X", 0xFFFFFF and color)
        setClipboard(hex)
        val finishSteps = {
            val c = p[2]
            val x = p[3]
            val closeIt = { if (x != null) tapAtD(x.x, x.y, 80, 1000L) { onDone() } else onDone() }
            if (c != null) tapAtD(c.x, c.y, 80, 900L) { closeIt() } else closeIt()
        }
        handler.postDelayed({
            if (!running) return@postDelayed
            tapAtD(p[0]!!.x, p[0]!!.y, 80, 1300L) {
                tapAtD(p[1]!!.x, p[1]!!.y, 80, 1000L) {
                    if (typeHex(hex)) {
                        handler.postDelayed({ if (running) finishSteps() }, 700)
                    } else {
                        toast("تعذّر الكتابة تلقائياً: اكتب $hex بنفسك")
                        waitStep("اكتب $hex في حقل HEX بنفسك (الرمز في الحافظة) ثم اضغط متابعة") {
                            handler.postDelayed({ if (running) finishSteps() }, 500)
                        }
                    }
                }
            }
        }, 400)
    }

    // اختبار مستقل لتغيير اللون: يطبّق الأحمر مرة واحدة ثم تتحقق بنفسك
    private fun testColor() {
        if (colorPts == null) { toast("علّم اللون أولاً (🎨)"); return }
        if (running) return
        running = true
        toast("اختبار: سيُطبَّق الأحمر #FF0000")
        applyColor(0xFFFF0000.toInt()) {
            running = false
            toast("انتهى. ارسم خطاً بيدك: هل هو أحمر؟")
        }
    }

    private fun newLayer(onDone: () -> Unit) {
        val a = layerP0
        val b = layerP1
        if (a == null || b == null) { onDone(); return }
        tapAt(a.x, a.y, 60) {
            tapAt(b.x, b.y, 60) {
                tapAt(a.x, a.y, 60) { onDone() }
            }
        }
    }

    // ---------- الرسم ----------
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(card)
        card = null
        removeOverlay(banner)
        banner = null
    }

    private fun startDrawing() {
        val r = rect
        val src = Shared.phases
        if (src.isEmpty()) { toast("اختر صورة من التطبيق أولاً"); return }
        if (r == null) { toast("حدّد منطقة الرسم (⛶) أولاً"); return }
        if (running) return

        val iw = Shared.imgW.toFloat()
        val ih = Shared.imgH.toFloat()
        val sc = Math.min(r.width() / iw, r.height() / ih)
        val ox = r.left + (r.width() - iw * sc) / 2f
        val oy = r.top + (r.height() - ih * sc) / 2f
        fun mx(px: Float) = ox + px * sc
        fun my(py: Float) = oy + py * sc

        val mapped = src.map { ph ->
            val ms = ph.strokes.map { st -> st.map { PointF(mx(it.x), my(it.y)) } }
            Phase(
                ph.color, ph.label, splitLong(order(ms)), ph.fast,
                if (ph.pickX >= 0f) mx(ph.pickX) else -1f,
                if (ph.pickY >= 0f) my(ph.pickY) else -1f,
                ph.fills?.map { PointF(mx(it.x), my(it.y)) },
                ph.blend
            )
        }
        running = true
        curColor = -1
        stepNo = 0
        toast("جاري التحضير...")
        if (mapped.any { it.fills != null }) {
            handler.postDelayed({ runFillMode(mapped) }, 1200)
        } else {
            handler.postDelayed({ runPhase(mapped, 0) }, 1200)
        }
    }

    private fun runPhase(ps: List<Phase>, idx: Int) {
        if (!running) return
        if (idx >= ps.size) {
            running = false
            toast("انتهى الرسم 🎉")
            return
        }
        val ph = ps[idx]
        if (ph.blend) {
            if (Shared.layers) { toast("التنعيم يحتاج طبقة واحدة، تم تخطيه"); runPhase(ps, idx + 1); return }
            toast(ph.label)
            selectSel(smudgeSel, "اختر أداة التنعيم (Smudge) بنفسك ثم اضغط متابعة") {
                drawNext(ph.strokes, 0, true) {
                    selectTool(false) { runPhase(ps, idx + 1) }
                }
            }
            return
        }
        toast("${ph.label} (${idx + 1}/${ps.size})")
        val go = {
            if (running) drawNext(ph.strokes, 0, ph.fast) { runPhase(ps, idx + 1) }
        }
        if (ps.size == 1) {
            go()
            return
        }
        if (colorPts != null) {
            applyColor(ph.color) { if (Shared.layers) newLayer { go() } else go() }
        } else {
            showColorCard(ph, idx + 1, ps.size) { handler.postDelayed({ go() }, 700) }
        }
    }

    // ---------- وضع Fill ----------
    private fun tapSeq(list: List<PointF?>, i: Int, onDone: () -> Unit) {
        if (!running) return
        if (i >= list.size) { onDone(); return }
        val p = list[i]
        if (p == null) { tapSeq(list, i + 1, onDone); return }
        tapAt(p.x, p.y, 60) { tapSeq(list, i + 1, onDone) }
    }

    // اختيار الأداة: بالتعليم المحفوظ، وإلا يطلب منك اختيارها يدوياً
    private fun selectSel(sel: List<PointF?>?, prompt: String, onDone: () -> Unit) {
        if (!running) return
        if (sel != null) {
            tapSeq(sel, 0) { handler.postDelayed({ if (running) onDone() }, 500) }
        } else {
            waitStep(prompt) { handler.postDelayed({ if (running) onDone() }, 500) }
        }
    }

    private fun selectTool(fill: Boolean, onDone: () -> Unit) = selectSel(
        if (fill) fillSel else brushSel,
        if (fill) "اختر أداة التعبئة (Fill) في Sketchbook بنفسك ثم اضغط متابعة"
        else "اختر الفرشاة/القلم الرفيع في Sketchbook بنفسك ثم اضغط متابعة",
        onDone
    )

    private fun setColorThen(ph: Phase, total: Int, onDone: () -> Unit) {
        if (!running) return
        if (ph.color == curColor) { onDone(); return }
        stepNo++
        if (colorPts != null) {
            applyColor(ph.color) { curColor = ph.color; onDone() }
        } else {
            showColorCard(ph, stepNo, total) {
                curColor = ph.color
                handler.postDelayed({ if (running) onDone() }, 700)
            }
        }
    }

    private fun tapSeeds(seeds: List<PointF>, i: Int, onDone: () -> Unit) {
        if (!running) return
        if (i >= seeds.size) { onDone(); return }
        tapAtD(seeds[i].x, seeds[i].y, 50, 450L) { tapSeeds(seeds, i + 1, onDone) }
    }

    private fun runFillMode(ps: List<Phase>) {
        val total = ps.size
        val tasks = ArrayList<(() -> Unit) -> Unit>()
        // لكل لون: لون ← طبقة جديدة ← حدود المنطقة ← أداة Fill ← ضغطات التعبئة ← العودة للفرشاة
        for (ph in ps) {
            val seeds = ph.fills
            if (ph.strokes.isEmpty() && seeds.isNullOrEmpty()) continue
            tasks.add { next ->
                showBanner("${ph.label}\nاللون ${String.format("#%06X", 0xFFFFFF and ph.color)}")
                setColorThen(ph, total) {
                    newLayer {
                        drawNext(ph.strokes, 0, ph.fast) {
                            if (seeds.isNullOrEmpty()) {
                                next()
                            } else {
                                selectTool(true) {
                                    tapSeeds(seeds, 0) { selectTool(false) { next() } }
                                }
                            }
                        }
                    }
                }
            }
        }
        fun go(i: Int) {
            if (!running) return
            if (i >= tasks.size) {
                running = false
                removeOverlay(banner); banner = null
                toast("انتهى الرسم 🎉")
                return
            }
            tasks[i].invoke { go(i + 1) }
        }
        go(0)
    }

    // تقسيم المسارات الطويلة جداً حتى لا تتجاوز حد مدة الإيماءة
    private fun splitLong(list: List<List<PointF>>): List<List<PointF>> {
        val out = ArrayList<List<PointF>>()
        for (st in list) {
            var cur = ArrayList<PointF>()
            var len = 0f
            for (k in st.indices) {
                if (cur.isNotEmpty()) {
                    val dx = st[k].x - cur.last().x
                    val dy = st[k].y - cur.last().y
                    len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                }
                cur.add(st[k])
                if (len > 18000f && k < st.size - 1) {
                    out.add(cur)
                    cur = ArrayList()
                    cur.add(st[k])
                    len = 0f
                }
            }
            if (cur.size >= 2) out.add(cur)
        }
        return out
    }

    private fun order(list: List<List<PointF>>): List<List<PointF>> {
        if (list.isEmpty() || list.size > 1500) return list
        val rem = list.toMutableList()
        val out = ArrayList<List<PointF>>()
        var cx = 0f
        var cy = 0f
        while (rem.isNotEmpty()) {
            var best = -1
            var bd = Float.MAX_VALUE
            var rev = false
            for (i in rem.indices) {
                val a = rem[i].first()
                val b = rem[i].last()
                val da = (a.x - cx) * (a.x - cx) + (a.y - cy) * (a.y - cy)
                val db = (b.x - cx) * (b.x - cx) + (b.y - cy) * (b.y - cy)
                if (da < bd) { bd = da; best = i; rev = false }
                if (db < bd) { bd = db; best = i; rev = true }
            }
            val st = rem.removeAt(best)
            val o = if (rev) st.reversed() else st
            out.add(o)
            cx = o.last().x
            cy = o.last().y
        }
        return out
    }

    private fun drawNext(strokes: List<List<PointF>>, i: Int, fast: Boolean, onDone: () -> Unit) {
        if (!running) return
        if (i >= strokes.size) { onDone(); return }
        val jit = if (fast) 0.5f else 1f
        val pts = strokes[i].map {
            PointF(it.x + (Random.nextFloat() * 2f - 1f) * jit, it.y + (Random.nextFloat() * 2f - 1f) * jit)
        }
        if (pts.size < 2) { drawNext(strokes, i + 1, fast, onDone); return }

        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        var len = 0f
        for (k in 1 until pts.size) {
            val dx = pts[k].x - pts[k - 1].x
            val dy = pts[k].y - pts[k - 1].y
            len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        for (k in 1 until pts.size - 1) {
            path.quadTo(pts[k].x, pts[k].y, (pts[k].x + pts[k + 1].x) / 2f, (pts[k].y + pts[k + 1].y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)

        val mult = Shared.speed.coerceIn(1f, 10f)
        // التلوين (خطوط مستقيمة) يتحمل سرعة عالية؛ الخطوط الخارجية المنحنية أبطأ حتى لا تتكسر
        val base = if (fast) 0.8f + Random.nextFloat() * 0.5f else 0.5f + Random.nextFloat() * 0.5f
        // خط مستقيم (نقطتان) يتحمل أعلى سرعة؛ المنحنيات والمسارات المتعرجة أبطأ حتى لا تُقصَّر زواياها
        val straight = pts.size == 2
        val speed = if (straight) base * mult else base * (1f + (mult - 1f) * 0.25f)
        val duration = (len / speed).toLong().coerceIn(if (mult > 1f) 35L else 120L, 55000L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val m2 = Shared.speed.coerceIn(1f, 10f)
                val pause = if (m2 <= 1f) {
                    if (fast) {
                        if (Random.nextInt(40) == 0) Random.nextLong(800, 2000) else Random.nextLong(30, 150)
                    } else {
                        if (Random.nextInt(12) == 0) Random.nextLong(1500, 3500) else Random.nextLong(100, 500)
                    }
                } else {
                    Math.max(5L, (Random.nextLong(30, 150) / m2).toLong())
                }
                handler.postDelayed({ drawNext(strokes, i + 1, fast, onDone) }, pause)
            }
            override fun onCancelled(g: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }
}
